-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2017 年 05 月 20 日 01:08
-- 服务器版本: 5.0.45
-- PHP 版本: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- 数据库: `project1`
--

-- --------------------------------------------------------

--
-- 表的结构 `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) collate utf8_unicode_ci NOT NULL,
  `productid` varchar(255) collate utf8_unicode_ci NOT NULL,
  `src` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` varchar(255) collate utf8_unicode_ci NOT NULL,
  `price` varchar(255) collate utf8_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- 导出表中的数据 `product`
--

INSERT INTO `product` (`id`, `username`, `productid`, `src`, `description`, `price`, `amount`) VALUES
(2, '18328506704', '1', '../images/datails (10).jpg', 'ZTE中兴 Blade V8 绝代双“焦”-仿生双摄+3D拍照', '¥1499.0', 17),
(3, '18328502667', '2', '../images/datails (1).jpg', '描述,自己测试用的', '¥899.0', 1),
(4, '18328506704', '3', '../images/details13.jpg', '测试所用的', '¥999.0', 1);

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) collate utf8_unicode_ci NOT NULL,
  `password` varchar(255) collate utf8_unicode_ci NOT NULL,
  `phone` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='项目的登录注册表' AUTO_INCREMENT=6 ;

--
-- 导出表中的数据 `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `phone`) VALUES
(1, '18328506704', '123456', 2147483647),
(3, '18328506703', '1234567', 2147483647),
(4, '18328506702', '12345678', 2147483647),
(5, '18828506704', '1234567', 2147483647);
